// function carga()
// {

  console.log("test") ;
  var valor=5;
  console.log(valor);
//  valor="philipe"+1;
  valor=valor+1
    console.log(valor);
    if (valor==1) {
      console.log(valor);
    } else {
      console.log(valor);
    }

    while (valor>1) {
       valor--;
       console.log("en while");
    }
    for (var i = 0; i < 5; i++) {
       console.log("en for");
    }
// }
  //alert("aler");
