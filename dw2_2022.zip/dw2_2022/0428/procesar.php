<pre>
<?php
if ($_POST['nombre']=="usuario" and $_POST["contranha"]=="segundo")
{
print_r($_POST);
} else
{
echo "usted no tiene permitido ver el contenido";

}



 ?>
 </pre>
