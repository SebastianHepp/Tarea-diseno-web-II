<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
         <link rel="stylesheet" href="/dw2_2022/node_modules/bootstrap/dist/css/bootstrap.min.css">
  </head>
  <body>
    <?php
    	include('libs/menu.php')
     ?>
     <script type='text/javascript' src='/dw2_2022/node_modules/bootstrap/dist/js/bootstrap.js'></script>
  </body>
</html>