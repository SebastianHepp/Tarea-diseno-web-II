<nav class="navbar navbar-light bg-light" style=" margin-bottom: 30px">
  <p class="form-inline" style=" margin-left: 5%; margin-top: 1% ;">
    <a class="btn btn-outline-secondary" href="/dw2_personas/ciudades/" >Ciudades</a>
    <a class="btn btn-outline-secondary" href="/dw2_personas/personas/"  >Personas</a>
  </p>
</nav>
